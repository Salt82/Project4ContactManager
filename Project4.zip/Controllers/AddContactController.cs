﻿using ContactProject.Data;
using ContactProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Linq;

public class ContactsController : Controller
{
    private readonly ApplicationDbContext _context;

    public ContactsController(ApplicationDbContext context)
    {
        _context = context;
    }

    public IActionResult Index()
    {
        var contacts = _context.Contacts
            .Include(c => c.Category) // Include Category for display
            .ToList();

        return View(contacts);
    }


    // GET: /Contacts/AddContact
    public IActionResult Add()
    {
        return View("Add");
    }

    public IActionResult Details(int id)
    {
        var contact = _context.Contacts
            .Include(c => c.Category) // Include the Category for eager loading
            .FirstOrDefault(c => c.Id == id);

        if (contact == null)
        {
            return NotFound();
        }
        return View(contact);
    }


    [HttpGet]
    public IActionResult Delete(int id)
    {
        var contact = _context.Contacts.FirstOrDefault(c => c.Id == id);
        if (contact == null)
        {
            return NotFound();
        }
        return View(contact);
    }

    [HttpPost]
    public IActionResult DeleteConfirmed(int id)
    {
        var contact = _context.Contacts.FirstOrDefault(c => c.Id == id);
        if (contact != null)
        {
            _context.Contacts.Remove(contact);
            _context.SaveChanges();
        }
        return Redirect("~/");
    }

    [HttpGet]
    public IActionResult Edit(int id)
    {
        var contact = _context.Contacts
            .Include(c => c.Category) // Include category for display
            .FirstOrDefault(c => c.Id == id);

        if (contact == null)
        {
            return NotFound();
        }

        // Pass categories for dropdown pre-filling
        ViewBag.Categories = new SelectList(_context.Categories, "Id", "Name", contact.CategoryId);

        return View(contact); // Pass existing contact to the view
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Edit(Contact contact)
    {
        if (ModelState.IsValid)
        {
            _context.Contacts.Update(contact);
            _context.SaveChanges();
            return Redirect("~/");
        }

        // Retain selected category if validation fails
        ViewBag.Categories = new SelectList(_context.Categories, "Id", "Name", contact.CategoryId);

        return View(contact);
    }

    // POST: /Contacts/AddContact
    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult AddContact(Contact contact)
    {
        if (ModelState.IsValid)
        {
            _context.Contacts.Add(contact);
            _context.SaveChanges();

            return Redirect("~/"); // Redirects back to the homepage (http://localhost:5152/)
        }

        return View(contact);
    }
}

