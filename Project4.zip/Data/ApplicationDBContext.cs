﻿using ContactProject.Models;
using Microsoft.EntityFrameworkCore;
using ContactProject.Models;

namespace ContactProject.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Contact> Contacts { get; set; }

        public DbSet<Category> Categories { get; set; }
    }
}
